package com.koreait.study.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.koreait.study.dto.Member;

@Repository
public class GalleryBoardDAO {

	@Autowired
	private SqlSession sqlSession;
	
	/* method */
	
	
	
}
