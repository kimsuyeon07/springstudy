package com.koreait.study.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GalleryBoardController {

	private SqlSession sqlSession;
	
	@Autowired
	public GalleryBoardController(SqlSession sqlSession) {
		super();
		this.sqlSession = sqlSession;
	}
	
	
	// 매핑에 따른 Command 작업	
	@GetMapping(value="galleryBoardPage.do")
	public String galleryBoardPage() {
		return "galleryBoard/galleryBoard";
	}
}
